#include <iostream>
#include <conio.h>
#include <string>
#include "wektor.h"
#include "wezel.h"
#include "dywan.h"

using namespace std;

// G��wna logika dywanu:
//Pierwszy funkcja najpierw przelicza godzine na system dziesi�tny ( minuty *1.66) na ko�cu zmienia dziesi�tny na minutowy( 0.xx *60)
//St�d dwie funkcje, jedna dla godzin druga dla minut

int main()
{
	
cout <<"                                          ."<<endl;
cout <<"                                        J**h"<<endl;
cout <<"                                        M  4"<<endl;
cout <<"                                        *  ="<<endl;
cout <<"                                      ,xnMbnx,"<<endl;
cout <<"                                    ,'*???????*.           .;!!!!!!!!;;"<<endl;
cout <<"     cccc,                         `? $* c- JF`$  .       &lt;!!!'``````&lt;!!;"<<endl;
cout <<" ????$$$$$$$$c,                  .*-.    *  *.,.=* z     !!'          !!!&gt;"<<endl;
cout <<"        *??$$$$$$$cc,.        ,c$$$$cc,,,...,,ccc$$$$.  '!!           !!!&gt;"<<endl;
cout <<"            *?$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$c !!        .,;!!!!"<<endl;
cout <<"               `*?$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$.&lt;!   ,;;!!!!!!!'`"<<endl;
cout <<"                  `*?$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$'! ;!!''`````"<<endl;
cout <<"                     `?$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$'!&lt;'"<<endl;
cout <<"                        *?$$$$$$$$$$$$$$$$$$$$$$$$$$$$$F;!! ,."<<endl;
cout <<"                           *?$$$$$$$$$$$$$$$$$$$$$$$$$* `!, !!!&gt;"<<endl;
cout <<"                              *?$$$$$$$$$$$$$$$$$$$$F    `&lt;;.;&lt;!!"<<endl;
cout <<"                                  *??$$$$$$$$$$$P**         `''"<<endl;
cout <<"                                       .. . .,."<<endl;
cout <<"                                    .MMMMMMMMMMMn"<<endl;
cout <<"                                   c,**?????????*."<<endl;
cout <<"                                 . ?* $P 4cr $$ ?P"<<endl;
cout <<"                                 *Mn. * ? *  * * ,nMP"<<endl;
cout <<"                                    *??44nmnmMPPP** "<<endl;

	//klasy
	wezly przelicz;
	wektor wektor;
	dywan dywan;
	//zmienne
	string wektor_dywanu;
	string wektor_wiatru;
	int droga;
	double godzina;
	int predkosc_dywanu = 25;
	int predkosc_wiatru;
	//koniec
	
	//zadanie pierwsze
cout <<"Zadanie pierwsze:"<<endl;
godzina = 17;
wektor_dywanu = "W";
wektor_wiatru = "E";
droga = 300;
predkosc_wiatru = 10;
//przeliczanie / wy�wietlanie godzin
cout << dywan.czas_przybycia_godzina(godzina, droga, wektor.wektorek(wektor_dywanu,wektor_wiatru, predkosc_dywanu, przelicz.wezlynams(predkosc_wiatru)));
cout <<":";//rozdzielenie godzina:minuta
//przeliczanie / wy�wietlanie minut
cout <<dywan.czas_przybycia_minuty(godzina, droga, wektor.wektorek(wektor_dywanu,wektor_wiatru, predkosc_dywanu, przelicz.wezlynams(predkosc_wiatru)));
cout << " Godzina przybycia."<<endl;
	//koniec zadanie pierwsze
	
	//zadanie drugi
cout <<"Zadanie drugie:"<<endl;
godzina = 11.20;
droga = 500;
wektor_dywanu = "S";
wektor_wiatru = "S";
predkosc_wiatru = 2;
cout << dywan.czas_przybycia_godzina2(godzina, droga, wektor.wektorek(wektor_dywanu,wektor_wiatru, predkosc_dywanu, przelicz.wezlynams(predkosc_wiatru)),przelicz.wezlynams(predkosc_wiatru)) ;
cout<<":";
cout<<dywan.czas_przybycia_minuty2(godzina, droga, wektor.wektorek(wektor_dywanu,wektor_wiatru, predkosc_dywanu, przelicz.wezlynams(predkosc_wiatru)),przelicz.wezlynams(predkosc_wiatru));
cout<< " Godzina przybycia."<<endl;

//zadanie trzecie
cout <<"Zadanie trzecie:"<<endl;
godzina = 10.15;
droga = 270;
predkosc_wiatru = 8;
wektor_dywanu = "E";
wektor_wiatru = "W";
//przeliczanie / wy�wietlanie godzin
cout << dywan.czas_przybycia_godzina(godzina, droga, wektor.wektorek(wektor_dywanu,wektor_wiatru, predkosc_dywanu, przelicz.wezlynams(predkosc_wiatru)));
cout <<":";//rozdzielenie godzina:minuta
//przeliczanie / wy�wietlanie minut
cout <<dywan.czas_przybycia_minuty(godzina, droga, wektor.wektorek(wektor_dywanu,wektor_wiatru, predkosc_dywanu, przelicz.wezlynams(predkosc_wiatru)));
cout << " Godzina przybycia."<<endl;


//zadanie czwarte
cout <<"Zadanie czwarte:"<<endl;




}
