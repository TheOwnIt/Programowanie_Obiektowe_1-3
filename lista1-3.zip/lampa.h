#include <iostream>
#include <conio.h>
#include <string>

using namespace std;
int lampa{



}
