#include <iostream>
#include <conio.h>
#include <string>
using namespace std;

//Przeliczanie wezly na m/s
class wezly
{
	public:
		double wezlynams( double a);

	
};
double wezly::wezlynams(double a){
	return(a*0.51);
}
