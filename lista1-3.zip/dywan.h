#include <iostream>
#include <conio.h>
#include <string>

using namespace std;

// G��wna logika dywanu:
//Pierwszy funkcja najpierw przelicza godzine na system dziesi�tny ( minuty *1.66) na ko�cu zmienia dziesi�tny na minutowy( 0.xx *60)
//St�d dwie funkcje, jedna dla godzin druga dla minut
class dywan
{
	public:
		//funkcja liczenia zadania 1
		double czas_przybycia_godzina(double czas_start, double droga, double predkosc)	;
		double czas_przybycia_minuty(double czas_start, double droga, double predkosc)	;
		//funkcja liczenia zadania 2
		double czas_przybycia_godzina2(double czas_start, double droga, double prodkosc, double predkosc2);
		double czas_przybycia_minuty2(double czas_start, double droga, double prodkosc, double predkosc2);
		//funkcja liczenia zadania 3
		
		//funkcja liczenia zadania 4
		
	
};
//Funkcja liczenia zadania 1
double dywan::czas_przybycia_godzina(double czas_start, double droga, double predkosc){
	predkosc = predkosc *3.6;
	int godziny = czas_start+(droga / predkosc);
	//double minuty = ((czas_start+(droga / predkosc) - godziny) /100)*60;
	return(godziny);
	
	//return(czas_start+(droga / predkosc));
	
}
double dywan::czas_przybycia_minuty(double czas_start, double droga, double predkosc){
	predkosc = predkosc *3.6;
	int godziny = czas_start+(droga / predkosc);
	int minuty = ((czas_start+(droga / predkosc) - godziny) *60);
	
	return(minuty);
	
	//return(czas_start+(droga / predkosc));
	
}
//Funkcja liczenia zadania 2
double dywan::czas_przybycia_godzina2(double czas_start, double droga, double predkosc, double predkosc2){
	predkosc = predkosc *3.6;
	predkosc2 = predkosc2 *3.6;
	
	double predkosc_bez_wiatru = predkosc - predkosc2;
	int godz_start = czas_start;
	czas_start = (czas_start - godz_start) * 1.66;
	czas_start = czas_start + godz_start;
	
	//double czas2 = ;
	
	 //265,82 km bez wiatru
	 //2:57 - czas bez wiatru + 2:30 z wiatrem = 5:27
	 //11:20 + 5:27 = 16:47
	// Czas - 2.5h * predko�� = droga bez wiatru / predko�� bez wiatru = czas przebycia tej drogi bez wiatru
	double czas = (((droga / predkosc) - 2.5) * predkosc) /predkosc_bez_wiatru;
	int godzina = czas;
	
	
	int godziny = czas_start+czas+2.5;
	
	//double minuty = ((czas_start+(droga / predkosc) - godziny) /100)*60;
	
	return(godziny);
	
	//return(czas_start+(droga / predkosc));
	
}
double dywan::czas_przybycia_minuty2(double czas_start, double droga, double predkosc, double predkosc2){
	int godz_start = czas_start;
	czas_start = (czas_start - godz_start) * 1.66;
	czas_start = czas_start + godz_start;
	
	predkosc = predkosc *3.6;
	predkosc2 = predkosc2 *3.6;
	
	double predkosc_bez_wiatru = predkosc - predkosc2;
	double czas = (((droga / predkosc) - 2.5) * predkosc) /predkosc_bez_wiatru;
	
	
	
	int godziny = czas_start+czas+2.5;
	
	int minuty = ((czas_start+(czas+2.5) - godziny) *60);
	
	return(minuty);
	
	//return(czas_start+(droga / predkosc));
	
}
//Funkcja liczenia zadania 3


//Funkcja liczenia zadania 4



